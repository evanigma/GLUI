#pragma once

struct ColorSwatch
{
	ColorSwatch(int c1, int c2, int c3, int colorMode);
	
	static const int RGB = 0;
	static const int HSV = 1;
	
	int h;
	int s;
	int v;
};
