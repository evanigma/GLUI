#include "ColorSwatch.h"

ColorSwatch::ColorSwatch(int c1, int c2, int c3, int colorMode)
{
	h = c1;
	
}
